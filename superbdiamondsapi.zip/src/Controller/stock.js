const Stock = require("../Schema/stock");
const User = require("../Schema/user");

const createStock = async (req, res) => {
  try {
    const newStock = new Stock(req.body);
    const user_email = req.user.email;
    const { last_stock_id, invoice_no } = newStock;
    console.log(last_stock_id);

    const user = await User.findOne({ email: user_email });
    if (!user) {
      return res.status(404).json({ success: false, error: "User not found." });
    }
    user.last_stock_id = last_stock_id;
    user.invoice_no = invoice_no;
    await newStock.save();
    await user.save();
    res
      .status(201)
      .json({ success: true, message: "Stock data saved successfully." });
  } catch (error) {
    console.error("Error saving stock data:", error);
    res
      .status(500)
      .json({ success: false, error: "Failed to save stock data." });
  }
};

const viewStock = async (req, res) => {
  try {
    const filters = { ...req.body, ...req.query };

    const stocks = await Stock.find(filters);
    if (stocks) {
      res.status(400);
    }
    res.status(200).json(stocks);
  } catch (error) {
    res.status(500).json({ message: "Failed to retrieve stock data", error });
  }
};
module.exports = { createStock, viewStock };
