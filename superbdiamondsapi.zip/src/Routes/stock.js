const express = require("express");
const { createStock, viewStock } = require("../Controller/stock");
const { authenticate } = require("../utils/jwt");

const router = express.Router();

router.use(authenticate);
router.post("/create-stock", createStock);
router.post("/view-stock", viewStock);

module.exports = router;
