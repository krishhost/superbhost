// const express = require("express");
// const { GetParty, AddParty } = require("../Controller/auth");
// const { authenticate } = require("../utils/jwt");

// const router = express.Router();
// router.use(authenticate);

// router.post("/party/:identifier", AddParty);
// router.get("/party/:identifier", GetParty);

// module.exports = router;
