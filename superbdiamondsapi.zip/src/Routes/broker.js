// const express = require("express");
// const { GetBroker, AddBroker } = require("../Controller/auth");
// const { authenticate } = require("../utils/jwt");

// const router = express.Router();
// router.use(authenticate);

// router.post("/broker/:identifier", AddBroker);
// router.get("/broker/:identifier", GetBroker);

// module.exports = router;
